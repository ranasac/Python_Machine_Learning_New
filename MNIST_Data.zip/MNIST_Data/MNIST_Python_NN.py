# -*- coding: utf-8 -*-
"""
Created on Sun Feb  4 17:04:46 2018

@author: ranas
"""
from __future__ import print_function
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
#% matplotlib inline

df_train = pd.read_csv('mnist_train.csv')
df_test = pd.read_csv('mnist_test.csv')

x_train = df_train.iloc[:,1:]
y_train = df_train.iloc[:,0]
x_test = df_test.iloc[:,1:]
y_test = df_test.iloc[:,0]

nn = MLPClassifier(activation = 'logistic', solver = 'sgd', hidden_layer_sizes = (10,15), random_state=1)

nn.fit(x_train, y_train)

y_pred = nn.predict(x_test)

y_test = y_test.values

count = 0
for i in range(len(y_test)):
    if (y_pred[i]== y_test[i]):
        count += 1

perc_correct = count/ len(y_test)
print("Total percent correctly classified: %f" % perc_correct)

# Plot any training input set
train_inp_plot = 100
plt.imshow(x_train.values[train_inp_plot,0:].reshape(28,28), cmap=plt.cm.gray)
plt.title("Training Input: %d" % train_inp_plot)

# Plot any test input set
test_inp_plot = 100
plt.imshow(x_test.values[test_inp_plot,0:].reshape(28,28), cmap=plt.cm.gray)
plt.title("Testing Input: %d" % test_inp_plot)

# qualitative evaluation of classification model
target_names = np.unique(y_train)
print(classification_report(y_test, y_pred))
#print(confusion_matrix(y_test, y_pred, labels=target_names))
plt.imshow(confusion_matrix(y_test, y_pred, labels=target_names)) #plot confusion matrix


