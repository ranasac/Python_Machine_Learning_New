# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 19:02:07 2018

@author: ranas
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import dim_red_fun as f1

df = pd.read_excel('data_python.xlsx')
print(df)

df = df.values # Convert dataframe into numpy array
(df_m, df_std, df_norm) = f1.data_norm_zscore_fun(df)

#Calculate Covariance Function
df_norm_cov = f1.sample_cov_fun(df_norm)

# Perform Singular Value Decomposition
(U,S,V) = f1.svd_fun(df_norm_cov)

#Projection of Data on first principal component or reduced dimension
proj_1 = f1.proj_fun(V,df_norm,1,1)
var_pres_1 = f1.var_preserve_check(df_norm,proj_1) #check to see how much variance is preserved

#Projection of Data on second principal component or reduced dimension
proj_2 = f1.proj_fun(V,df_norm,2,2)
var_pres_2 = f1.var_preserve_check(df_norm,proj_2) #check to see how much variance is preserved

#Projection of Data on all principal components or reduced dimension = actual dimensions
proj_all = f1.proj_fun(V,df_norm,1,len(V))
var_pres_all = f1.var_preserve_check(df_norm,proj_all) #check to see how much variance is preserved

# Reconstruction based on first principal component
x_approx_1 = f1.reconst_fun(V,proj_1,1,1)

# Reconstruction based on second principal component
x_approx_2 = f1.reconst_fun(V,proj_2,2,2)

# Reconstruction based on all principal components
x_approx_all = f1.reconst_fun(V,proj_all,1,len(V))

# Convert from normalized to real scale
x_approx_1_real = f1.date_denorm_zscore_fun(x_approx_1,df_m,df_std)
x_approx_2_real = f1.date_denorm_zscore_fun(x_approx_2,df_m,df_std)
x_approx_all_real = f1.date_denorm_zscore_fun(x_approx_all,df_m,df_std)

# plot data and reduced dimensions in normalized scale
plt.figure(1)
plt.plot(df_norm[0,:],df_norm[1,:],'ro',x_approx_1[0,:],x_approx_1[1,:],'bs',x_approx_2[0,:],x_approx_2[1,:],'bs'  )
plt.show()

# plot in normalized scale for all principal components
plt.figure(2)
plt.plot(df_norm[0,:],df_norm[1,:],'ro',x_approx_all[0,:],x_approx_all[1,:],'bs' )
plt.show()

# plot in real scale
plt.figure(3)
plt.plot(df[0,:],df[1,:],'ro',x_approx_1_real[0,:],x_approx_1_real[1,:],'bs',x_approx_2_real[0,:],x_approx_2_real[1,:],'bs'  )
plt.show()








