# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 19:03:10 2018

@author: ranas
"""

def data_norm_zscore_fun(df):
    import numpy as np
    (row,col) = df.shape
    df_m = df.mean(axis=1).reshape(row,1)
    df_std = df.std(axis=1, ddof=1).reshape(row,1)
    df_norm = np.divide(np.subtract(df,df_m), df_std)
    return df_m, df_std, df_norm

def sample_cov_fun(df_norm):
    import numpy as np
    df_norm_cov = np.dot(df_norm, df_norm.transpose())/ (len(df_norm.transpose())-1)
    return df_norm_cov

def date_denorm_zscore_fun(df_norm, df_m, df_std):
    import numpy as np
    df_real = np.add(np.multiply(df_norm,df_std), df_m)
    return df_real

def svd_fun(df_norm_cov):
    import numpy as np
    V, s, U = np.linalg.svd(df_norm_cov, full_matrices=True)
    (v_row,v_col) = V.shape 
    (u_row, u_col) = U.shape
    s_row = len(s)
    S = np.zeros((u_row, v_col), dtype=float)
    S[:s_row,:s_row] = np.diag(s)
    return U, S, V

def proj_fun(V,df_norm,ncomp_start, ncomp_end):
    import numpy as np
    proj = np.dot(V[:,ncomp_start-1:ncomp_end].transpose(),df_norm)
    return proj

def reconst_fun(V,proj,ncomp_start, ncomp_end):
    import numpy as np
    x_approx = np.dot(np.reshape(V[:,ncomp_start-1:ncomp_end], (len(V),ncomp_end+1-ncomp_start)),proj)
    return x_approx

def var_preserve_check(df_norm,proj):
    import numpy as np
    var_orig = np.var(df_norm, ddof=1)
    var_red = np.var(proj, ddof=1)
    var_pres = var_red/ var_orig
    return var_pres
    
    
    
    
    
    